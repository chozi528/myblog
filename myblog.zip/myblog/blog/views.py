from django.http import Http404
from django.shortcuts import render, get_object_or_404, HttpResponseRedirect, reverse
from blog.models import Post, Commnet
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from .forms import CommentForm
import markdown


# Create your views here.


def index(request):

    limit = 10  # 每页显示的记录数
    topics = Post.objects.all().order_by('-created_time')

    # 分页代码开始
    pageation = Paginator(topics, limit)  # 实例化一个分页对象
    page = request.GET.get('page')  # 获取页码
    try:
        topics = pageation.page(page)  # 获取某页对应的记录
    except PageNotAnInteger:  # 如果页码不是个整数
        topics = pageation.page(1)  # 取第一页的记录
    except EmptyPage:  # 如果页码太大，没有相应的记录
        topics = pageation.page(pageation.num_pages)  # 取最后一页的记录

    return render(request, 'blog/index.html', context={'title': '我的博客',
                                                       'topics': topics,})


def detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    # 用markdown渲染文章body页面
    post.body = markdown.markdown(post.body,
                                  extensions=[
                                      'markdown.extensions.extra',
                                      'markdown.extensions.codehilite',
                                      'markdown.extensions.toc',
                                  ])
    # 文章评论数量增加
    post.addreadnum()

    # ------------评论功能开始
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            cleaned_data = form.cleaned_data
            print(cleaned_data)
            cleaned_data['post'] = post
            Commnet.objects.create(**cleaned_data)

        return HttpResponseRedirect(reverse('detail', args=(post.id,)))

    else:
        form = CommentForm()


        ctx = {
            'blog': post,
            'comments': post.commnet_set.all().order_by('-postime'),
            'form': form
        }

        return render(request, 'blog/detail.html', ctx)


def search(request):
    q = request.GET.get('q')
    error_msg = ''

    if not q:
        error_msg = '请输入关键词'
        return render(request, 'blog/index.html', {'error_msg': error_msg})

    topics = Post.objects.filter(title__icontains=q) | Post.objects.filter(body__icontains=q)
    return render(request, 'blog/index.html', {'error_msg': error_msg,
                                               'topics': topics})


def tagslist(request, tags):
    try:
        topics = Post.objects.filter(category__name=tags)
    except:
        raise Http404

    return render(request, 'blog/index.html', context={'topics': topics})


def userlist(request, user):
    try:
        topics = Post.objects.filter(author__username=user)
    except:
        raise Http404

    return render(request, 'blog/index.html', context={'topics': topics})
