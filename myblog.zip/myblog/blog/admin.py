from django.contrib import admin
from . import models
# Register your models here.


class PostAdmin(admin.ModelAdmin):
    list_display = ['title', 'created_time', 'modified_time', 'category', 'author']

    class Media:
        js = (
            '/static/js/kindeditor/kindeditor-all-min.js',
            '/static/js/kindeditor/lang/zh_CN.js',
            '/static/js/kindeditor/config.js',
        )


class TagAdmin(admin.ModelAdmin):
    list_display = ['pk','name']


class CommnetAdmin(admin.ModelAdmin):
    list_display = ['name','email','content','post','postime']




admin.site.register(models.Post,PostAdmin)
admin.site.register(models.Commnet,CommnetAdmin)
admin.site.register(models.Category)
admin.site.register(models.Tag,TagAdmin)

