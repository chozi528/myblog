//news
KindEditor.ready(function(K) {
    K.create('textarea[name="body"]', {
        width : "800px",
        height : "500px",
        uploadJson: '/admin/uploads/kindeditor',
    });
});