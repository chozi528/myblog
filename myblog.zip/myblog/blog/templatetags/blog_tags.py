from ..models import Post, Commnet
from django import template

register = template.Library()


@register.simple_tag
def new_post(num = 5):               # num--获取最新文章的数目

    return Post.objects.all().order_by('-created_time')[:num]


@register.simple_tag
def hot_post(num = 5):              # num 获取热门阅读文章
    return Post.objects.all().order_by('-readnum')[:num]


@register.simple_tag
def hot_commnet(num = 3):              # num 获取热门评论文章
    return Commnet.objects.all().order_by('post_id')[:num]
